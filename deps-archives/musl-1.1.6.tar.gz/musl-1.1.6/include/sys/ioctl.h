#ifndef	_SYS_IOCTL_H
#define	_SYS_IOCTL_H
#ifdef __cplusplus
extern "C" {
#endif

#include <bits/ioctl.h>

int ioctl (int, int, ...);

#ifdef __cplusplus
}
#endif
#endif
